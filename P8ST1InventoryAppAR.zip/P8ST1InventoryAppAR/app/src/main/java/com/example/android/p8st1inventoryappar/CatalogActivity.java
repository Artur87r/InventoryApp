package com.example.android.p8st1inventoryappar;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.annotation.StringRes;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.app.LoaderManager;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.CursorLoader;
import android.content.Intent;
import android.content.Loader;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.android.p8st1inventoryappar.data.ProductContract.ProductEntry;
import com.example.android.p8st1inventoryappar.data.ProductDbHelper;


public class CatalogActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor> {

    private static final int INVENTORY_LOADER = 0;

    ItemCursorAdapter productCursorAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catalog);

        // Setup FAB to open EditorActivity
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CatalogActivity.this, EditorActivity.class);
                startActivity(intent);
            }
        });


        ListView itemsListView = findViewById(R.id.inventory_list_view);

        View emptyView = findViewById(R.id.empty_view);

        itemsListView.setEmptyView(emptyView);

        productCursorAdapter = new ItemCursorAdapter(this, null);

        itemsListView.setAdapter(productCursorAdapter);

        //Item click listener to edit currently touched item
        itemsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, final View view, int position, long id) {

                Intent intent = new Intent(CatalogActivity.this, EditorActivity.class);
                intent.setData(ContentUris.withAppendedId(ProductEntry.CONTENT_URI, id));
                startActivity(intent);
            }
        });

        getLoaderManager().initLoader(INVENTORY_LOADER, null, this);
    }

    //Inserting data in product table to test the database read and delete methods
    private void insertDummyData() {

        // Create a ContentValues object where column names are the keys,
        // and product's attributes are the values.
        ContentValues contentValues = new ContentValues();

        contentValues.put(ProductEntry.COLUMN_PRODUCT_NAME, "1.1 SERIE");
        contentValues.put(ProductEntry.COLUMN_PRODUCT_QUANTITY, 2);
        contentValues.put(ProductEntry.COLUMN_PRODUCT_PRICE, 2999);
        contentValues.put(ProductEntry.COLUMN_PRODUCT_SUPPLIER_NAME, "TREK");
        contentValues.put(ProductEntry.COLUMN_PRODUCT_SUPPLIER_PHONE_NUMBER, "805858735");

        //Get the Uri of the newly inserted row and display it to user in toast message
        Uri newRowUri = getContentResolver().insert(ProductEntry.CONTENT_URI, contentValues);

        if (newRowUri == null) {
            Toast.makeText(this, R.string.insert_test_item_failed, Toast.LENGTH_SHORT).show();
        }
    }

    //Inflate the option menu with catalog_options menu resource file
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_catalog, menu);
        return true;
    }

    //Methods to invoke for each chosen option in the menu
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {

            //Insert data in items table
            case R.id.action_insert_data:
                insertDummyData();
                return true;

            //Delete all rows in the items table
            case R.id.action_delete_all_entries:
                clearProductsTable();
                return true;
        }

        return super.onOptionsItemSelected(item);
    }

    //This method will delete all rows in the items table without deleting the table
    public void clearProductsTable() {
        int countRowsDeleted = getContentResolver().delete(ProductEntry.CONTENT_URI, null, null);
        Toast.makeText(this, String.format(getString(R.string.all_count_rows_deleted), countRowsDeleted), Toast.LENGTH_SHORT).show();
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {

        // Define a projection that specifies which columns from the database
        // you will actually use after this query.
        String[] projection = new String[]{
                ProductEntry._ID,
                ProductEntry.COLUMN_PRODUCT_NAME,
                ProductEntry.COLUMN_PRODUCT_QUANTITY,
                ProductEntry.COLUMN_PRODUCT_PRICE};

        return new CursorLoader(this, ProductEntry.CONTENT_URI, projection,
                null, null, null);
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {

        productCursorAdapter.swapCursor(data);
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {

        productCursorAdapter.swapCursor(null);
    }
}